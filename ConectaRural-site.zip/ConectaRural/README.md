# ConectaRural

Site demonstrativo de marketplace rural feito com HTML, CSS e JavaScript puro.

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra `index.html` em um navegador atualizado.

## Recursos
- Layout responsivo em tema laranja.
- Busca e filtros por categoria.
- Produtos de demonstração.
- Formulário para adicionar anúncios na página.
- Login demonstrativo apenas com nome.
- Carteira demonstrativa com saldo inicial de R$ 0,00.
- Interface de simulação de Pix, sem movimentar dinheiro.

## Importante
Este projeto é apenas um protótipo front-end. Os anúncios não são enviados a um servidor e podem desaparecer ao recarregar a página. Não há autenticação segura, banco de dados, conta bancária, integração com bancos, Pix real, processamento de pagamentos ou transferência de dinheiro. Para operar de verdade, será necessário backend, banco de dados, segurança, conformidade legal e integração com um provedor de pagamentos autorizado.
